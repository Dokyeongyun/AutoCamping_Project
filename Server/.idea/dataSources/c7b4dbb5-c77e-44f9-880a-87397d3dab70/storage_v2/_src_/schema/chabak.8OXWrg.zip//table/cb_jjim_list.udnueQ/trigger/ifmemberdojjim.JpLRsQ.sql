create definer = chabak@localhost trigger ifMemberDoJJim
    after insert
    on cb_jjim_list
    for each row
begin
		declare x int default 1;
		

	update cb_chabak_location set jjim = jjim + x where placeName = new.placeName;
	END;

