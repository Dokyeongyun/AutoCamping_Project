create definer = chabak@localhost trigger ifMemberDoJJimUndo
    after delete
    on cb_jjim_list
    for each row
begin
		
        update cb_chabak_location
        set jjim = jjim - 1
      

  where placeName = old.placeName;
        END;

