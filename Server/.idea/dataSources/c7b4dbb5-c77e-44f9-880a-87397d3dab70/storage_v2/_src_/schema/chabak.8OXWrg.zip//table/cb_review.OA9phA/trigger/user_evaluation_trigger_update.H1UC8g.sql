create definer = chabak@localhost trigger user_evaluation_trigger_update
    after update
    on cb_review
    for each row
begin
    declare myVal double;
    
    select avg(evaluation_point) into myVal from user_evaluation where placeId = new.placeId;
	update cb_chabak_location set avg_point = myVal	where placeId = new.placeId;
	END;

